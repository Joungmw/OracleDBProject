<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css2/bootstrap.min.css">
<style type="text/css">
	</style>

</head>
<body>
	<br><br><br><br><br><br><br><br><br>
	<div class="container">
		<div class="row">
			<div class="col-md-4 col-md-offset-4">
				<div class="login-panel panel panel-default">
					<div class="panel-heading">
						<h3 class="panel-title">회원정보수정</h3>
					</div>
					<div class="panel-body">
						<form action='member_check.php' name='login' method='post'>
					    <fieldset>
						
							<label for="inputName">비밀번호</label>
							<input type="password" placeholder="Password" name="pw" class="form-control" maxlength="20"></div>
                            <button class="btn btn-lg btn-primary btn-block" type="submit">확인</button>
                        </form>
                        <br>
	                    </fieldset>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	</body>
</html>
